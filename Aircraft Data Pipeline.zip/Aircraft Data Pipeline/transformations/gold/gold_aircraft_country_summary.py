"""
Gold Layer: Aircraft observations summarized by origin country.

Provides per-country counts, airborne/on-ground breakdowns, distinct aircraft,
and altitude/velocity statistics for geographic analysis.
"""

from pyspark import pipelines as dp
from pyspark.sql import functions as F


@dp.materialized_view(
    name="gold_aircraft_country_summary",
    comment="Aircraft observations by origin country: counts, airborne/ground breakdowns, distinct aircraft, and altitude/velocity statistics.",
)
def gold_aircraft_country_summary():
    return (
        spark.read.table("silver_opensky_states")
        .groupBy("origin_country")
        .agg(
            F.count("*").alias("total_observations"),
            F.sum(F.when(F.col("flight_status") == "AIRBORNE", 1).otherwise(0)).alias("airborne_count"),
            F.sum(F.when(F.col("flight_status") == "ON_GROUND", 1).otherwise(0)).alias("on_ground_count"),
            F.countDistinct("icao24").alias("distinct_aircraft"),
            F.countDistinct("callsign").alias("distinct_callsigns"),
            F.round(F.avg("barometric_altitude_m"), 2).alias("avg_barometric_altitude_m"),
            F.max("barometric_altitude_m").alias("max_barometric_altitude_m"),
            F.round(F.avg("velocity_mps"), 2).alias("avg_velocity_mps"),
            F.max("velocity_mps").alias("max_velocity_mps"),
        )
        .orderBy(F.col("total_observations").desc())
    )