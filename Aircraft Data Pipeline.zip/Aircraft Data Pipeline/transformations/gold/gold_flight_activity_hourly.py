"""
Gold Layer: Flight activity aggregated by hour.

Provides hourly counts of aircraft observations, airborne/on-ground breakdowns,
distinct aircraft counts, and altitude/velocity statistics for dashboard use.
"""

from pyspark import pipelines as dp
from pyspark.sql import functions as F


@dp.materialized_view(
    name="gold_flight_activity_hourly",
    comment="Hourly flight activity summary: observation counts, airborne/ground breakdowns, distinct aircraft, and altitude/velocity statistics.",
)
def gold_flight_activity_hourly():
    return (
        spark.read.table("silver_opensky_states")
        .groupBy(
            "position_date",
            "position_year",
            "position_month",
            "position_day",
            "position_hour",
        )
        .agg(
            F.count("*").alias("total_observations"),
            F.sum(F.when(F.col("flight_status") == "AIRBORNE", 1).otherwise(0)).alias("airborne_count"),
            F.sum(F.when(F.col("flight_status") == "ON_GROUND", 1).otherwise(0)).alias("on_ground_count"),
            F.sum(F.when(F.col("flight_status") == "UNKNOWN", 1).otherwise(0)).alias("unknown_status_count"),
            F.countDistinct("icao24").alias("distinct_aircraft"),
            F.countDistinct("callsign").alias("distinct_callsigns"),
            F.round(F.avg("barometric_altitude_m"), 2).alias("avg_barometric_altitude_m"),
            F.max("barometric_altitude_m").alias("max_barometric_altitude_m"),
            F.round(F.avg("geometric_altitude_m"), 2).alias("avg_geometric_altitude_m"),
            F.max("geometric_altitude_m").alias("max_geometric_altitude_m"),
            F.round(F.avg("velocity_mps"), 2).alias("avg_velocity_mps"),
            F.max("velocity_mps").alias("max_velocity_mps"),
        )
        .orderBy("position_date", "position_hour")
    )