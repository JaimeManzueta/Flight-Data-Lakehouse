"""
Gold Layer: Flight activity summarized by geographic grid cells.

Groups valid-position observations into 5-degree latitude/longitude grid cells
for map visualizations and geographic flight density analysis.
"""

from pyspark import pipelines as dp
from pyspark.sql import functions as F


@dp.materialized_view(
    name="gold_flight_geographic_activity",
    comment="Flight activity by 5-degree geographic grid: observation counts, airborne/ground breakdowns, altitude/velocity averages, distinct aircraft.",
)
def gold_flight_geographic_activity():
    return (
        spark.read.table("silver_opensky_states")
        .filter(F.col("has_valid_position"))
        .withColumn("lat_bin", F.floor(F.col("latitude") / 5) * 5)
        .withColumn("lat_bin_end", F.floor(F.col("latitude") / 5) * 5 + 5)
        .withColumn("lon_bin", F.floor(F.col("longitude") / 5) * 5)
        .withColumn("lon_bin_end", F.floor(F.col("longitude") / 5) * 5 + 5)
        .groupBy("lat_bin", "lat_bin_end", "lon_bin", "lon_bin_end")
        .agg(
            F.count("*").alias("total_observations"),
            F.sum(F.when(F.col("flight_status") == "AIRBORNE", 1).otherwise(0)).alias("airborne_count"),
            F.sum(F.when(F.col("flight_status") == "ON_GROUND", 1).otherwise(0)).alias("on_ground_count"),
            F.round(F.avg("barometric_altitude_m"), 2).alias("avg_altitude_m"),
            F.round(F.avg("velocity_mps"), 2).alias("avg_velocity_mps"),
            F.countDistinct("icao24").alias("distinct_aircraft"),
        )
        .orderBy("lat_bin", "lon_bin")
    )