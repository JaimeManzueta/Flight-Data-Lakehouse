"""
Gold Layer: Aircraft observations summarized by altitude band.

Groups observations into altitude bands (Ground, Low, Medium, High, Very High, Unknown)
with velocity and vertical rate statistics for flight-level analysis.
"""

from pyspark import pipelines as dp
from pyspark.sql import functions as F


@dp.materialized_view(
    name="gold_aircraft_altitude_summary",
    comment="Aircraft observations by altitude band: counts, airborne/ground breakdowns, velocity and vertical rate statistics.",
)
def gold_aircraft_altitude_summary():
    return (
        spark.read.table("silver_opensky_states")
        .withColumn(
            "altitude_band",
            F.when(F.col("on_ground") == True, F.lit("Ground"))
             .when(
                F.col("barometric_altitude_m").isNull() & F.col("geometric_altitude_m").isNull(),
                F.lit("Unknown"),
            )
             .when(
                F.coalesce(F.col("barometric_altitude_m"), F.col("geometric_altitude_m")) < 1500,
                F.lit("Low (0-1500m)"),
            )
             .when(
                F.coalesce(F.col("barometric_altitude_m"), F.col("geometric_altitude_m")) < 6000,
                F.lit("Medium (1500-6000m)"),
            )
             .when(
                F.coalesce(F.col("barometric_altitude_m"), F.col("geometric_altitude_m")) < 12000,
                F.lit("High (6000-12000m)"),
            )
             .otherwise(F.lit("Very High (12000m+)")),
        )
        .groupBy("altitude_band")
        .agg(
            F.count("*").alias("total_observations"),
            F.sum(F.when(F.col("flight_status") == "AIRBORNE", 1).otherwise(0)).alias("airborne_count"),
            F.round(F.avg("velocity_mps"), 2).alias("avg_velocity_mps"),
            F.max("velocity_mps").alias("max_velocity_mps"),
            F.round(F.avg("vertical_rate_mps"), 2).alias("avg_vertical_rate_mps"),
            F.countDistinct("icao24").alias("distinct_aircraft"),
        )
        .orderBy("altitude_band")
    )