"""
Silver Layer: Cleaned and standardized OpenSky state-vector observations.

Transforms raw Bronze data (s3_opensky_data.raw_aircraft_schema.output_folder) into
an analytics-ready Silver table with:
- Meaningful column names (renamed from numbered columns)
- ICAO24 aircraft identifier (column 0, not in original user mapping)
- UTC timestamps converted from Unix epoch
- Cleaned string fields (callsign, origin_country, squawk)
- Validated geographic coordinates with quality indicators
- Derived unit conversions (km/h, knots, feet, fpm)
- Data quality columns and overall status
- Logical column ordering for dashboard readiness

NULL Handling Policy:
- NULLs are preserved where they represent genuinely unavailable OpenSky data.
- NULL altitude does NOT mean altitude = 0.
- NULL velocity does NOT mean velocity = 0.
- NULL coordinates do NOT mean the aircraft is at 0,0.
- No values are fabricated or replaced with arbitrary defaults.

Source: OpenSky Network REST API /states endpoint
Raw Column Mapping (OpenSky state vector fields):
  0  = icao24              (ICAO 24-bit transponder hex address)
  1  = callsign             (flight callsign)
  2  = origin_country       (country of origin)
  3  = time_position        (Unix epoch seconds — time of position)
  4  = last_contact         (Unix epoch seconds — last contact)
  5  = longitude            (degrees)
  6  = latitude             (degrees)
  7  = barometric_altitude  (meters)
  8  = on_ground            (boolean)
  9  = velocity             (meters per second)
  10 = true_track           (degrees, 0-360)
  11 = vertical_rate        (meters per second)
  12 = sensors              (array of sensor IDs — all NULL in current dataset;
                             ingested as BIGINT due to schema inference limitation)
  13 = geometric_altitude   (meters)
  14 = squawk               (transponder squawk code, string for leading zeros)
  15 = spi                  (special purpose indicator, boolean)
  16 = position_source      (0=ADS-B, 1=ASTERIX, 2=MLAT, 3=FLARM)

Unique Observation Key:
  icao24 + time_position (or icao24 + last_contact when time_position is NULL)
  All 53 records have distinct icao24 values in the current dataset.
  If icao24 were absent, no reliable unique aircraft identifier could be constructed.

Limitations:
  - sensors (column 12) should be array<int> but was ingested as BIGINT (all NULL).
  - _rescued_data column is excluded from Silver (retained in Bronze for troubleshooting).
  - No registration/operator/aircraft-type information available in source data.
"""

from pyspark import pipelines as dp
from pyspark.sql import functions as F


@dp.materialized_view(
    name="silver_opensky_states",
    comment=(
        "Cleaned and standardized OpenSky state-vector observations. "
        "Transformed from raw Bronze data with proper column names, UTC timestamps, "
        "validated geographic data, derived measurement units, and data-quality indicators."
    ),
)
@dp.expect("icao24_not_null", "icao24 IS NOT NULL")
@dp.expect("time_position_valid", "time_position IS NULL OR time_position > 0")
@dp.expect("last_contact_valid", "last_contact IS NULL OR last_contact > 0")
@dp.expect("longitude_valid_range", "longitude IS NULL OR (longitude >= -180 AND longitude <= 180)")
@dp.expect("latitude_valid_range", "latitude IS NULL OR (latitude >= -90 AND latitude <= 90)")
@dp.expect("true_track_valid_range", "true_track_deg IS NULL OR (true_track_deg >= 0 AND true_track_deg <= 360)")
def silver_opensky_states():
    # Read from raw Bronze table (not owned by this pipeline)
    raw = spark.read.table("s3_opensky_data.raw_aircraft_schema.output_folder")

    # Step 1: Rename numbered columns to meaningful snake_case names
    # NOTE: Column 0 = icao24 (not in original user mapping but present in source)
    df = raw.select(
        F.col("0").alias("icao24"),
        F.col("1").alias("callsign"),
        F.col("2").alias("origin_country"),
        F.col("3").alias("time_position"),
        F.col("4").alias("last_contact"),
        F.col("5").alias("longitude"),
        F.col("6").alias("latitude"),
        F.col("7").alias("barometric_altitude_m"),
        F.col("8").alias("on_ground"),
        F.col("9").alias("velocity_mps"),
        F.col("10").alias("true_track_deg"),
        F.col("11").alias("vertical_rate_mps"),
        F.col("12").alias("sensors"),
        F.col("13").alias("geometric_altitude_m"),
        F.col("14").alias("squawk"),
        F.col("15").alias("spi"),
        F.col("16").alias("position_source"),
    )

    # Step 3: Clean string fields — trim whitespace, empty strings -> NULL
    df = df.withColumn(
        "callsign",
        F.when(F.trim(F.col("callsign")) == "", None)
         .otherwise(F.trim(F.col("callsign"))),
    )
    df = df.withColumn(
        "origin_country",
        F.when(F.trim(F.col("origin_country")) == "", None)
         .otherwise(F.trim(F.col("origin_country"))),
    )
    df = df.withColumn(
        "squawk",
        F.when(F.trim(F.col("squawk")) == "", None)
         .otherwise(F.trim(F.col("squawk"))),
    )

    # Step 2: Convert Unix epoch seconds -> UTC timestamps
    # Keep original epoch values; create new timestamp columns
    df = df.withColumn(
        "position_timestamp_utc",
        F.when(
            F.col("time_position").isNotNull() & (F.col("time_position") > 0),
            F.to_timestamp(F.from_unixtime(F.col("time_position"))),
        ).otherwise(F.lit(None).cast("timestamp")),
    )
    df = df.withColumn(
        "last_contact_timestamp_utc",
        F.when(
            F.col("last_contact").isNotNull() & (F.col("last_contact") > 0),
            F.to_timestamp(F.from_unixtime(F.col("last_contact"))),
        ).otherwise(F.lit(None).cast("timestamp")),
    )

    # Step 2: Derived time fields from position_timestamp_utc
    df = df.withColumn("position_date", F.to_date(F.col("position_timestamp_utc")))
    df = df.withColumn("position_year", F.year(F.col("position_timestamp_utc")))
    df = df.withColumn("position_month", F.month(F.col("position_timestamp_utc")))
    df = df.withColumn("position_day", F.dayofmonth(F.col("position_timestamp_utc")))
    df = df.withColumn("position_hour", F.hour(F.col("position_timestamp_utc")))
    df = df.withColumn("position_minute", F.minute(F.col("position_timestamp_utc")))
    df = df.withColumn("position_day_of_week", F.dayofweek(F.col("position_timestamp_utc")))

    # Step 6: Derived speed fields (do NOT overwrite original velocity_mps)
    df = df.withColumn(
        "velocity_kmh",
        F.when(
            F.col("velocity_mps").isNotNull(),
            F.round(F.col("velocity_mps") * 3.6, 2),
        ).otherwise(F.lit(None).cast("double")),
    )
    df = df.withColumn(
        "velocity_knots",
        F.when(
            F.col("velocity_mps").isNotNull(),
            F.round(F.col("velocity_mps") * 1.943844, 2),
        ).otherwise(F.lit(None).cast("double")),
    )

    # Step 6: Derived altitude fields (meters -> feet; do NOT overwrite originals)
    df = df.withColumn(
        "barometric_altitude_ft",
        F.when(
            F.col("barometric_altitude_m").isNotNull(),
            F.round(F.col("barometric_altitude_m") * 3.28084, 2),
        ).otherwise(F.lit(None).cast("double")),
    )
    df = df.withColumn(
        "geometric_altitude_ft",
        F.when(
            F.col("geometric_altitude_m").isNotNull(),
            F.round(F.col("geometric_altitude_m") * 3.28084, 2),
        ).otherwise(F.lit(None).cast("double")),
    )

    # Step 6: Derived vertical rate (m/s -> feet per minute)
    df = df.withColumn(
        "vertical_rate_fpm",
        F.when(
            F.col("vertical_rate_mps").isNotNull(),
            F.round(F.col("vertical_rate_mps") * 196.850, 2),
        ).otherwise(F.lit(None).cast("double")),
    )

    # Step 7: Flight status derived from on_ground
    df = df.withColumn(
        "flight_status",
        F.when(F.col("on_ground").isNull(), F.lit("UNKNOWN"))
         .when(F.col("on_ground") == True, F.lit("ON_GROUND"))
         .when(F.col("on_ground") == False, F.lit("AIRBORNE"))
         .otherwise(F.lit("UNKNOWN")),
    )

    # Step 8: Position source interpretation (OpenSky documented codes)
    df = df.withColumn(
        "position_source_name",
        F.when(F.col("position_source") == 0, F.lit("ADS-B"))
         .when(F.col("position_source") == 1, F.lit("ASTERIX"))
         .when(F.col("position_source") == 2, F.lit("MLAT"))
         .when(F.col("position_source") == 3, F.lit("FLARM"))
         .otherwise(F.lit(None)),
    )

    # Step 5: Validate geographic data — has_valid_position
    df = df.withColumn(
        "has_valid_position",
        F.col("latitude").isNotNull()
        & F.col("longitude").isNotNull()
        & (F.col("latitude") >= -90)
        & (F.col("latitude") <= 90)
        & (F.col("longitude") >= -180)
        & (F.col("longitude") <= 180),
    )

    # Step 13: Data quality columns
    df = df.withColumn(
        "has_valid_timestamp",
        F.col("position_timestamp_utc").isNotNull(),
    )
    df = df.withColumn(
        "has_altitude",
        F.col("barometric_altitude_m").isNotNull()
        | F.col("geometric_altitude_m").isNotNull(),
    )
    df = df.withColumn("has_velocity", F.col("velocity_mps").isNotNull())
    df = df.withColumn("has_callsign", F.col("callsign").isNotNull())
    df = df.withColumn("has_origin_country", F.col("origin_country").isNotNull())

    # Step 13: Overall data quality status
    # VALID: valid timestamp + valid position + has altitude + has velocity
    # PARTIAL: valid timestamp but missing some fields
    # INVALID: no valid timestamp
    df = df.withColumn(
        "data_quality_status",
        F.when(~F.col("has_valid_timestamp"), F.lit("INVALID"))
         .when(
            F.col("has_valid_position")
            & F.col("has_altitude")
            & F.col("has_velocity"),
            F.lit("VALID"),
        )
         .otherwise(F.lit("PARTIAL")),
    )

    # Step 16: Select in logical column order
    return df.select(
        # 1. Aircraft identity
        "icao24",
        "callsign",
        # 2. Flight identity
        "origin_country",
        # 3. Timestamp
        "position_timestamp_utc",
        "last_contact_timestamp_utc",
        "position_date",
        "position_year",
        "position_month",
        "position_day",
        "position_hour",
        "position_minute",
        "position_day_of_week",
        # 4. Geographic position
        "latitude",
        "longitude",
        "has_valid_position",
        # 5. Altitude
        "barometric_altitude_m",
        "barometric_altitude_ft",
        "geometric_altitude_m",
        "geometric_altitude_ft",
        # 6. Speed
        "velocity_mps",
        "velocity_kmh",
        "velocity_knots",
        # 7. Direction
        "true_track_deg",
        # 8. Vertical movement
        "vertical_rate_mps",
        "vertical_rate_fpm",
        # 9. Flight status
        "on_ground",
        "flight_status",
        # 10. Other flight data
        "squawk",
        "spi",
        "position_source",
        "position_source_name",
        "sensors",
        # 11. Data-quality fields
        "has_altitude",
        "has_velocity",
        "has_callsign",
        "has_origin_country",
        "has_valid_timestamp",
        "data_quality_status",
        # 12. Source/API metadata (raw epoch values preserved)
        "time_position",
        "last_contact",
    )