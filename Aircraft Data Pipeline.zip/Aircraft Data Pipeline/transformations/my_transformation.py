# This file is intentionally left empty.
# Pipeline transformations are organized in the medallion architecture:
#   transformations/silver/silver_opensky_states.py       — Cleaned state-vector data
#   transformations/gold/gold_flight_activity_hourly.py     — Hourly flight activity
#   transformations/gold/gold_aircraft_country_summary.py    — Country-level summary
#   transformations/gold/gold_aircraft_altitude_summary.py  — Altitude band summary
#   transformations/gold/gold_flight_geographic_activity.py — Geographic grid activity